﻿﻿#define GLFW_DLL
#define GLEW_DLL
#include <iostream>
#include "glew-2.1.0/include/GL/glew.h"
#include "glfw-3.4.bin.WIN64/include/GLFW/glfw3.h"


int main()
{
    std::cout << "Hello World!\n";

    glfwInit();
    if (!glfwInit())
    {
        fprintf(stderr, "ERROR GLFW Init: \n");
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 1.0);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0.0);
    //glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    //glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* Okno;
    Okno = glfwCreateWindow(512, 512, "Okno", NULL, NULL);

    if (!Okno)
    {
        glfwTerminate();

    }
    glfwMakeContextCurrent(Okno);


    GLenum ret = glewInit();
    if (GLEW_OK != ret)
    {
        fprintf(stderr, "ERROR GLEW Init: \n", glewGetErrorString(ret));
        return -2;
    }

    while (!glfwWindowShouldClose(Okno))
    {
        glClear(GL_COLOR_BUFFER_BIT);
        glClearColor(1.0, 1.0, 0.5, 1.0);

        glBegin(GL_TRIANGLES);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.0, 1.0);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(-0.5, 0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.5, 0.5);

        glColor3f(0.2, 0.4, 1.0);  glVertex2f(-0.5, 0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(-0.5, -0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.0, -1.0);

        glColor3f(0.2, 0.4, 1.0);  glVertex2f(-0.5, -0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.0, -1.0);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.5, -0.5);

        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.0, -1.0);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.5, -0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.5, 0.5);

        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.5, -0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.5, 0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.0, 1.0);

        glColor3f(0.2, 0.4, 1.0);  glVertex2f(-0.5, 0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.5, -0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.5, 0.5);

        glColor3f(0.2, 0.4, 1.0);  glVertex2f(-0.5, 0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(-0.5, -0.5);
        glColor3f(0.2, 0.4, 1.0);  glVertex2f(0.5, -0.5);
        glEnd();
        glfwSwapBuffers(Okno);

        glfwPollEvents();
    }
    glfwTerminate();
}